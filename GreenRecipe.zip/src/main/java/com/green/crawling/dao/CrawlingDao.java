package com.green.crawling.dao;

import com.green.crawling.vo.CrawlingVo;

public interface CrawlingDao {

	void insertCrawling(CrawlingVo vo);

}
